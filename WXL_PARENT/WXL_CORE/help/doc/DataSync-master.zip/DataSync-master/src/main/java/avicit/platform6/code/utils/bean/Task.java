package avicit.platform6.code.utils.bean;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * 任务
 * 
 * @author wxl
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "task", propOrder = { "taskName", "svnUrl", "svnUser", "svnPwd"})
public class Task {

	/** 任务名称 */
	@XmlElement(name = "taskName", required = true)
	private String taskName;

	/** svn路径 */
	@XmlElement(name = "svnUrl", required = true)
	private String svnUrl;

	/** svn用户 */
	@XmlElement(name = "svnUser", required = true)
	private String svnUser;

	/** svn密码 */
	@XmlElement(name = "svnPwd", required = true)
	private String svnPwd;

	/**
	 * @return the taskName
	 */
	public String getTaskName() {
		return taskName;
	}

	/**
	 * @param taskName
	 *            the taskName to set
	 */
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	/**
	 * @return the svnUrl
	 */
	public String getSvnUrl() {
		return svnUrl;
	}

	/**
	 * @param svnUrl
	 *            the svnUrl to set
	 */
	public void setSvnUrl(String svnUrl) {
		this.svnUrl = svnUrl;
	}

	/**
	 * @return the svnUser
	 */
	public String getSvnUser() {
		return svnUser;
	}

	/**
	 * @param svnUser
	 *            the svnUser to set
	 */
	public void setSvnUser(String svnUser) {
		this.svnUser = svnUser;
	}

	/**
	 * @return the svnPwd
	 */
	public String getSvnPwd() {
		return svnPwd;
	}

	/**
	 * @param svnPwd
	 *            the svnPwd to set
	 */
	public void setSvnPwd(String svnPwd) {
		this.svnPwd = svnPwd;
	}
}

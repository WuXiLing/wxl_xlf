package avicit.platform6.svn.model;

import avicit.platform6.svn.conf.SvnConfig;
import avicit.platform6.svn.impl.SvnBaseImpl;
import avicit.platform6.svn.inf.ISvn;

public class DemoSvn {
	SvnLinkPojo svnLink;

	public SvnLinkPojo getSvnLink() {
		return svnLink;
	}

	/**
	 * 私有构造
	 */
	public DemoSvn() {
	}

	public DemoSvn(String svnAccount, String svnPassword, String repoPath) {
		this.svnLink = new SvnLinkPojo(repoPath, svnAccount, svnPassword);
	}

	/**
	 * 获取SVN操作
	 * 
	 * @param val
	 *            default 不设置日志状态 log 开启console日志状态
	 * @throws 没有操作匹配
	 * @return {@link ISvn}
	 */
	public ISvn execute(SvnConfig val) {
		ISvn is = null;
		switch (val.getVal()) {
		case "normal":
			is = new SvnBaseImpl(svnLink.getSvnAccount(), svnLink.getSvnPassword(), false, svnLink.getRepoPath());
			break;
		case "log":
			is = new SvnBaseImpl(svnLink.getSvnAccount(), svnLink.getSvnPassword(), true, svnLink.getRepoPath());
			break;
		default:

		}
		return is;
	}
}

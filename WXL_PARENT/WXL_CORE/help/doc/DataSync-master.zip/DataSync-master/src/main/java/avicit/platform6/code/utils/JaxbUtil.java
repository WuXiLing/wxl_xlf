package avicit.platform6.code.utils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

/**
 * Jaxb2工具类(操作xml和javaBean转换)
 * 
 * @author liangxf
 *
 */
public class JaxbUtil {

	/**
	 * JavaBean转换成xml 默认编码UTF-8
	 * 
	 * @param obj
	 * @param fileName
	 * @return
	 * @throws JAXBException
	 * @throws IOException
	 */
	public static String convertToXml(Object obj, String fileName) throws IOException, JAXBException {
		return convertToXml(obj, fileName, "UTF-8");
	}

	/**
	 * JavaBean转换成xml
	 * 
	 * @param obj
	 * @param encoding
	 * @return
	 * @throws IOException
	 * @throws JAXBException
	 */
	public static String convertToXml(Object obj, String fileName, String encoding) throws IOException, JAXBException {
		String result = null;
		File xmlFile = new File(fileName);
		if (xmlFile.exists()) {
			// SecurityManager securityManager = new SecurityManager();
			// securityManager.checkDelete(new File("").getCanonicalPath() +
			// File.separator + fileName);
			// xmlFile.delete();
		} else {
			xmlFile.getParentFile().mkdirs();
			xmlFile.createNewFile();
		}
		JAXBContext context = JAXBContext.newInstance(obj.getClass());
		Marshaller marshaller = context.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		marshaller.setProperty(Marshaller.JAXB_ENCODING, encoding);

		StringWriter writer = new StringWriter();
		marshaller.marshal(obj, writer);
		result = writer.toString();

		BufferedWriter out = new BufferedWriter(
				new OutputStreamWriter(new FileOutputStream(xmlFile), StandardCharsets.UTF_8));
		out.write(result);
		out.close();
		return result;
	}

	/**
	 * xml转换成JavaBean
	 * 
	 * @param xml
	 * @param c
	 * @return
	 * @throws JAXBException
	 */
	@SuppressWarnings("unchecked")
	public static <T> T converyToJavaBean(String xml, Class<T> c) throws JAXBException {
		T t = null;
		JAXBContext context = JAXBContext.newInstance(c);
		Unmarshaller unmarshaller = context.createUnmarshaller();
		t = (T) unmarshaller.unmarshal(new StringReader(xml));

		return t;
	}

	/**
	 * xml文件转换成JavaBean
	 *
	 * @param xmlFile
	 * @param c
	 * @return
	 * @throws JAXBException
	 */
	@SuppressWarnings("unchecked")
	public static <T> T converyToJavaBean(File xmlFile, Class<T> c) throws JAXBException {
		T t = null;
		if (xmlFile != null && xmlFile.exists() && xmlFile.isFile()) {
			JAXBContext context = JAXBContext.newInstance(c);
			Unmarshaller unmarshaller = context.createUnmarshaller();
			t = (T) unmarshaller.unmarshal(xmlFile);
		}

		return t;
	}
}

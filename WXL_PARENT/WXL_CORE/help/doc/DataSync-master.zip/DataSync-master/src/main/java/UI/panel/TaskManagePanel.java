package UI.panel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.Arrays;
import java.util.Vector;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel;
import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tmatesoft.svn.core.SVNException;

import UI.AppMainWindow;
import UI.ConstantsUI;
import UI.MyIconButton;
import avicit.platform6.code.utils.JaxbUtil;
import avicit.platform6.code.utils.bean.Avicit;
import avicit.platform6.code.utils.bean.Task;
import avicit.platform6.svn.conf.SvnConfig;
import avicit.platform6.svn.inf.ISvn;
import avicit.platform6.svn.model.DemoSvn;
import tools.DESPlus;
import tools.PropertyUtil;

/**
 * 任务管理面板
 * 
 * @author wxl
 *
 */
public class TaskManagePanel extends JPanel {

	private static final long serialVersionUID = 1L;

	private static final Logger logger = LoggerFactory.getLogger(TaskManagePanel.class);

	/** 测试按钮 */
	private static MyIconButton buttonTestLink;

	/** 保存按钮 */
	private static MyIconButton buttonSave;

	/** 任务名称 */
	private static JTextField textFieldTaskName;

	/** URL地址 */
	private static JTextField textFieldSvnUrl;

	/** 用户名 */
	private static JTextField textFieldSvnUser;

	/** 密码 */
	private static JPasswordField passwordFieldSvnPassword;

	/** 表格 */
	public static JTable tableFrom;

	/** 表格数据 */
	private static Object[][] tableDatas;

	private static Vector<Object> rowVector = new Vector<Object>();

	DefaultTableModel model = new DefaultTableModel();

	private static MyIconButton buttonNewBakFrom;

	/**
	 * 构造
	 */
	public TaskManagePanel() {
		initialize();
		initTableData();
		addComponent();
		setContent();
		addListener();
	}

	/**
	 * 初始化
	 */
	private void initialize() {
		this.setBackground(ConstantsUI.MAIN_BACK_COLOR);
		this.setLayout(new BorderLayout());
	}

	/**
	 * 添加组件
	 */
	private void addComponent() {
		this.add(getUpPanel(), BorderLayout.NORTH);
		this.add(getCenterPanel(), BorderLayout.CENTER);
		this.add(getDownPanel(), BorderLayout.SOUTH);

	}

	/**
	 * 上部面板
	 *
	 * @return
	 */
	private JPanel getUpPanel() {
		JPanel panelUp = new JPanel();
		panelUp.setBackground(ConstantsUI.MAIN_BACK_COLOR);
		panelUp.setLayout(new FlowLayout(FlowLayout.LEFT, ConstantsUI.MAIN_H_GAP, 5));

		JLabel labelTitle = new JLabel(PropertyUtil.getProperty("avicit.ui.task.manage"));
		labelTitle.setFont(ConstantsUI.FONT_TITLE);
		labelTitle.setForeground(ConstantsUI.TOOL_BAR_BACK_COLOR);
		panelUp.add(labelTitle);

		return panelUp;
	}

	/**
	 * 中部面板
	 *
	 * @return
	 */
	private JPanel getCenterPanel() {
		// 中间面板
		JPanel panelCenter = new JPanel();
		// 设置背景色
		panelCenter.setBackground(ConstantsUI.MAIN_BACK_COLOR);
		panelCenter.setLayout(new GridLayout(2, 1));

		// 设置Grid
		JPanel panelGridSetting = new JPanel();
		panelGridSetting.setBackground(ConstantsUI.MAIN_BACK_COLOR);
		panelGridSetting.setLayout(new FlowLayout(FlowLayout.LEFT, ConstantsUI.MAIN_H_GAP, 0));

		// 初始化组件
		JLabel labelTaskName = new JLabel(PropertyUtil.getProperty("avicit.ui.task.name"));
		JLabel labelSvnUrl = new JLabel(PropertyUtil.getProperty("avicit.ui.svn.url"));
		JLabel labelSvnUser = new JLabel(PropertyUtil.getProperty("avicit.ui.svn.user"));
		JLabel labelSvnPwd = new JLabel(PropertyUtil.getProperty("avicit.ui.svn.pwd"));
		textFieldTaskName = new JTextField();
		textFieldSvnUrl = new JTextField();
		textFieldSvnUser = new JTextField();
		passwordFieldSvnPassword = new JPasswordField();

		// 字体
		labelTaskName.setFont(ConstantsUI.FONT_NORMAL);
		labelSvnUrl.setFont(ConstantsUI.FONT_NORMAL);
		labelSvnUser.setFont(ConstantsUI.FONT_NORMAL);
		labelSvnPwd.setFont(ConstantsUI.FONT_NORMAL);
		textFieldTaskName.setFont(ConstantsUI.FONT_NORMAL);
		textFieldSvnUrl.setFont(ConstantsUI.FONT_NORMAL);
		textFieldSvnUser.setFont(ConstantsUI.FONT_NORMAL);
		passwordFieldSvnPassword.setFont(ConstantsUI.FONT_NORMAL);

		// 大小
		labelTaskName.setPreferredSize(ConstantsUI.LABLE_SIZE_ITEM);
		labelSvnUrl.setPreferredSize(ConstantsUI.LABLE_SIZE_ITEM);
		labelSvnUser.setPreferredSize(ConstantsUI.LABLE_SIZE_ITEM);
		labelSvnPwd.setPreferredSize(ConstantsUI.LABLE_SIZE_ITEM);
		textFieldTaskName.setPreferredSize(ConstantsUI.TEXT_FIELD_SIZE_ITEM);
		textFieldSvnUrl.setPreferredSize(ConstantsUI.TEXT_FIELD_SIZE_ITEM);
		textFieldSvnUser.setPreferredSize(ConstantsUI.TEXT_FIELD_SIZE_ITEM);
		passwordFieldSvnPassword.setPreferredSize(ConstantsUI.TEXT_FIELD_SIZE_ITEM);

		// 组合元素
		panelGridSetting.add(labelTaskName);
		panelGridSetting.add(textFieldTaskName);
		panelGridSetting.add(labelSvnUrl);
		panelGridSetting.add(textFieldSvnUrl);
		panelGridSetting.repaint();
		panelGridSetting.add(labelSvnUser);
		panelGridSetting.add(textFieldSvnUser);
		panelGridSetting.add(labelSvnPwd);
		panelGridSetting.add(passwordFieldSvnPassword);

		panelCenter.add(panelGridSetting);
		panelCenter.add(getPanelGridBakFrom());
		return panelCenter;
	}

	DefaultTableModel defaultTableModel = null;
	/**
	 * 数据库来源Grid面板
	 *
	 * @return
	 */
	private JPanel getPanelGridBakFrom() {
		// 来源备份Grid
		JPanel panelGridBakFrom = new JPanel();
		panelGridBakFrom.setBackground(ConstantsUI.MAIN_BACK_COLOR);
		panelGridBakFrom.setLayout(new BorderLayout());

		JPanel panelFromControl = new JPanel();
		panelFromControl.setLayout(new GridLayout(1, 2));
		JPanel panelFromTable = new JPanel();
		panelFromTable.setLayout(new BorderLayout());

		// 初始化控制组件
		JPanel panelFromControlLeft = new JPanel();
		panelFromControlLeft.setLayout(new FlowLayout(FlowLayout.LEFT, ConstantsUI.MAIN_H_GAP, 5));
		panelFromControlLeft.setBackground(ConstantsUI.MAIN_BACK_COLOR);
		JPanel panelFromControlRight = new JPanel();
		panelFromControlRight.setLayout(new FlowLayout(FlowLayout.RIGHT, ConstantsUI.MAIN_H_GAP, 5));
		panelFromControlRight.setBackground(ConstantsUI.MAIN_BACK_COLOR);

		JLabel labelFrom = new JLabel(PropertyUtil.getProperty("avicit.ui.task.list"));
		labelFrom.setFont(new Font(PropertyUtil.getProperty("avicit.ui.font.family"), 0, 18));
		labelFrom.setForeground(Color.gray);
		panelFromControlLeft.add(labelFrom);

		buttonNewBakFrom = new MyIconButton(ConstantsUI.ICON_NEW_BAK, ConstantsUI.ICON_NEW_BAK_ENABLE, ConstantsUI.ICON_NEW_BAK_DISABLE, "");
		MyIconButton buttonRecvBakFrom = new MyIconButton(ConstantsUI.ICON_RECOVER_BAK, ConstantsUI.ICON_RECOVER_BAK_ENABLE, ConstantsUI.ICON_RECOVER_BAK_DISABLE, "");
		MyIconButton buttonDelBakFrom = new MyIconButton(ConstantsUI.ICON_DEL_BAK, ConstantsUI.ICON_DEL_BAK_ENABLE, ConstantsUI.ICON_DEL_BAK_DISABLE, "");
		panelFromControlRight.add(buttonNewBakFrom);
		panelFromControlRight.add(buttonRecvBakFrom);
		panelFromControlRight.add(buttonDelBakFrom);

		panelFromControl.add(panelFromControlLeft);
		panelFromControl.add(panelFromControlRight);

		panelGridBakFrom.add(panelFromControl, BorderLayout.NORTH);

		// 初始化表格组件
		Vector<String> vector = new Vector<String>();

		vector.add(PropertyUtil.getProperty("avicit.ui.task.table.head0"));
		vector.add(PropertyUtil.getProperty("avicit.ui.task.table.head1"));
		vector.add(PropertyUtil.getProperty("avicit.ui.task.table.head2"));
		
		defaultTableModel = new DefaultTableModel(rowVector, vector);
		tableFrom = new JTable(defaultTableModel);

		TableColumn tableColumn1 = new TableColumn();
		tableColumn1.setHeaderValue(PropertyUtil.getProperty("avicit.ui.task.table.head0"));
		TableColumn tableColumn2 = new TableColumn();
		tableColumn2.setHeaderValue(PropertyUtil.getProperty("avicit.ui.task.table.head0"));
		TableColumn tableColumn3 = new TableColumn();
		tableColumn3.setHeaderValue(PropertyUtil.getProperty("avicit.ui.task.table.head0"));

		// tableFrom.addColumn(tableColumn1);
		// tableFrom.addColumn(tableColumn2);
		// tableFrom.addColumn(tableColumn3);
		// tableFrom = new JTable(tableDatas, new String[] {
		// PropertyUtil.getProperty("avicit.ui.task.table.head0"),
		// PropertyUtil.getProperty("avicit.ui.task.table.head1"),
		// PropertyUtil.getProperty("avicit.ui.task.table.head2") });

		tableFrom.setFont(ConstantsUI.FONT_NORMAL);
		tableFrom.getTableHeader().setFont(ConstantsUI.FONT_NORMAL);
		tableFrom.getTableHeader().setBackground(ConstantsUI.TOOL_BAR_BACK_COLOR);
		tableFrom.setRowHeight(31);
		tableFrom.setGridColor(ConstantsUI.TABLE_LINE_COLOR);
		tableFrom.setSelectionBackground(ConstantsUI.TOOL_BAR_BACK_COLOR);
		// 设置列宽
		tableFrom.getColumnModel().getColumn(0).setPreferredWidth(50);
		tableFrom.getColumnModel().getColumn(0).setMaxWidth(50);
		tableFrom.getColumnModel().getColumn(2).setPreferredWidth(150);
		tableFrom.getColumnModel().getColumn(2).setMaxWidth(150);

		JScrollPane panelScroll = new JScrollPane(tableFrom);
		panelScroll.setBackground(ConstantsUI.MAIN_BACK_COLOR);
		panelGridBakFrom.add(panelScroll, BorderLayout.CENTER);

		return panelGridBakFrom;
	}

	static Avicit avicit = null;

	public static void initTableData() {

		try {
			File file = new File(ConstantsUI.CURRENT_DIR + File.separator + "config" + File.separator + "tasks.xml");
			if (file.exists()) {
				avicit = JaxbUtil.converyToJavaBean(file, Avicit.class);
				if (avicit.getTasks() != null && !avicit.getTasks().isEmpty()) {
					tableDatas = new Object[avicit.getTasks().size()][3];
					for (int i = 0; i < avicit.getTasks().size(); i++) {
						Task task = avicit.getTasks().get(i);
						tableDatas[i] = new Object[] { i + 1, task.getTaskName(), task.getSvnUser() };
                     Vector<Object> sObjects = new Vector();
                     sObjects.add(i + 1);
                     sObjects.add(task.getTaskName());
                     sObjects.add(task.getSvnUser());
                     rowVector.add(sObjects);
					}
				}
			} else {
				tableDatas = new Object[0][3];
			}
		} catch (JAXBException e) {
			tableDatas = new Object[0][3];
		}
	}

	/**
	 * 底部面板
	 *
	 * @return
	 */
	private JPanel getDownPanel() {
		JPanel panelDown = new JPanel();
		panelDown.setBackground(ConstantsUI.MAIN_BACK_COLOR);
		panelDown.setLayout(new FlowLayout(FlowLayout.RIGHT, ConstantsUI.MAIN_H_GAP, 15));

		buttonTestLink = new MyIconButton(ConstantsUI.ICON_TEST_LINK, ConstantsUI.ICON_TEST_LINK_ENABLE, ConstantsUI.ICON_TEST_LINK_DISABLE, "");
		buttonSave = new MyIconButton(ConstantsUI.ICON_SAVE, ConstantsUI.ICON_SAVE_ENABLE, ConstantsUI.ICON_SAVE_DISABLE, "");
		panelDown.add(buttonTestLink);
		panelDown.add(buttonSave);

		return panelDown;
	}

	/**
	 * 设置文本区内容
	 */
	public static void setContent() {

	}

	/**
	 * 为相关组件添加事件监听
	 */
	private void addListener() {

		// 保存事件
		buttonSave.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				try {
					DESPlus des = new DESPlus();

					Task task = new Task();
					task.setSvnPwd(des.encrypt(new String(passwordFieldSvnPassword.getPassword())));
					task.setSvnUrl(textFieldSvnUrl.getText());
					task.setSvnUser(des.encrypt(textFieldSvnUser.getText()));
					task.setTaskName(textFieldTaskName.getText());
					avicit.addTask(task);
					tableDatas = Arrays.copyOf(tableDatas, tableDatas.length + 1);
					tableDatas[tableDatas.length - 1] = new Object[] { tableDatas.length, task.getTaskName(), task.getSvnUser() };
					JaxbUtil.convertToXml(avicit, ConstantsUI.CURRENT_DIR + File.separator + "config" + File.separator + "tasks.xml");
					Vector<Object> sObjects = new Vector<Object>();
					sObjects.add(tableDatas.length);
					sObjects.add(task.getTaskName());
					sObjects.add(task.getSvnUser());
					rowVector.add(sObjects);
					tableFrom.repaint();
					JOptionPane.showMessageDialog(AppMainWindow.databasePanel, PropertyUtil.getProperty("ds.ui.save.success"), PropertyUtil.getProperty("ds.ui.tips"), JOptionPane.PLAIN_MESSAGE);
				} catch (Exception e1) {
					e1.getMessage();
					JOptionPane.showMessageDialog(AppMainWindow.databasePanel, PropertyUtil.getProperty("ds.ui.save.fail"), PropertyUtil.getProperty("ds.ui.tips"), JOptionPane.ERROR_MESSAGE);
					logger.error("Write to xml file error" + e1.toString());
				}

			}
		});

		// 测试连接事件
		buttonTestLink.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				ISvn svn;
				// 初始化实例
				DemoSvn ts = new DemoSvn(textFieldSvnUser.getText(), new String(passwordFieldSvnPassword.getPassword()), textFieldSvnUrl.getText());
				// 获得操作对象
				try {
					logger.debug("user:" + textFieldSvnUser.getText() + ";pwd:" + new String(passwordFieldSvnPassword.getPassword()));
					svn = ts.execute(SvnConfig.log);
					svn.createSVNRepository();
					svn.createSVNClientManager();
					svn.closeRepo();
					JOptionPane.showMessageDialog(AppMainWindow.databasePanel, PropertyUtil.getProperty("avicit.ui.svn.check.success"), PropertyUtil.getProperty("ds.ui.tips"),
							JOptionPane.PLAIN_MESSAGE);
				} catch (SVNException e1) {
					JOptionPane.showMessageDialog(AppMainWindow.databasePanel, PropertyUtil.getProperty("avicit.ui.svn.check.fail"), PropertyUtil.getProperty("ds.ui.tips"), JOptionPane.ERROR_MESSAGE);
				}
			}
		});

	}
}

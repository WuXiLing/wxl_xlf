package avicit.platform6.svn.model;

import java.util.Date;

/**
 * SVN资源库对象
 * 
 * @author wxl
 *
 */
public class SvnRepoPojo implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	private String commitMessage; // 提交信息
	private Date date; // 提交日期
	private String kind; // 提交方式 dir目录 file文件 none空 unknown 未知
	private String name;// 目录名
	private String repositoryRoot; // 资源库路径
	private long revision; // 提交的svn版本号
	private long size; // 提交的文件数
	private String url; // 更变的目录地址
	private String author;// 作者
	private String state;// 状态
	/**
	 * @return the commitMessage
	 */
	public String getCommitMessage() {
		return commitMessage;
	}
	/**
	 * @param commitMessage the commitMessage to set
	 */
	public void setCommitMessage(String commitMessage) {
		this.commitMessage = commitMessage;
	}
	/**
	 * @return the date
	 */
	public Date getDate() {
		return date;
	}
	/**
	 * @param date the date to set
	 */
	public void setDate(Date date) {
		this.date = date;
	}
	/**
	 * @return the kind
	 */
	public String getKind() {
		return kind;
	}
	/**
	 * @param kind the kind to set
	 */
	public void setKind(String kind) {
		this.kind = kind;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the repositoryRoot
	 */
	public String getRepositoryRoot() {
		return repositoryRoot;
	}
	/**
	 * @param repositoryRoot the repositoryRoot to set
	 */
	public void setRepositoryRoot(String repositoryRoot) {
		this.repositoryRoot = repositoryRoot;
	}
	/**
	 * @return the revision
	 */
	public long getRevision() {
		return revision;
	}
	/**
	 * @param revision the revision to set
	 */
	public void setRevision(long revision) {
		this.revision = revision;
	}
	/**
	 * @return the size
	 */
	public long getSize() {
		return size;
	}
	/**
	 * @param size the size to set
	 */
	public void setSize(long size) {
		this.size = size;
	}
	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}
	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}
	/**
	 * @return the author
	 */
	public String getAuthor() {
		return author;
	}
	/**
	 * @param author the author to set
	 */
	public void setAuthor(String author) {
		this.author = author;
	}
	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}
	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}
}

package avicit.platform6.code.utils.bean;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "avicit")
public class Avicit {

	/** 新增文件集合 */
	@XmlElementWrapper(name = "tasks")
	@XmlElement(name = "task", required = true)
	private List<Task> tasks = new ArrayList<Task>();

	/**
	 * @return the tasks
	 */
	public List<Task> getTasks() {
		return tasks;
	}

	/**
	 * @param tasks the tasks to set
	 */
	public void setTasks(List<Task> tasks) {
		this.tasks = tasks;
	}
	
	/**
	 * @param tasks the task to add
	 */
	public void addTask(Task task) {
		this.tasks.add(task);
	}
	
	/**
	 * @param tasks the tasks to add
	 */
	public void addTasks(List<Task> tasks) {
		this.tasks.addAll(tasks);
	}
}

package avicit.platform6.svn.model;

/**
 * 连接状态
 * 
 * @author wxl
 *
 */
public class SvnLinkPojo extends SvnAccountPojo {

	private static final long serialVersionUID = 1L;
	
	private String repoPath;// 库链接路径

	public SvnLinkPojo(String repoPath, String svnAccount, String svnPassword) {
		super(svnAccount, svnPassword);
		this.repoPath = repoPath;
	}

	public SvnLinkPojo(String svnAccount, String svnPassword) {
		super(svnAccount, svnPassword);
	}

	public String getRepoPath() {
		return repoPath;
	}

	public void setRepoPath(String repoPath) {
		this.repoPath = repoPath;
	}

}

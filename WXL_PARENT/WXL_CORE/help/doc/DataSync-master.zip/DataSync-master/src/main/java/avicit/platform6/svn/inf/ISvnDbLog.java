package avicit.platform6.svn.inf;

import java.io.File;
import java.util.Date;
import java.util.List;

import avicit.platform6.svn.conf.SvnConfig;

/**
 * 记录svn操作人
 * 
 * @param <T>
 * 
 * @author wxl
 * @date 2017年11月9日 下午2:13:14
 */
public interface ISvnDbLog<T> {
	/**
	 * 添加日志
	 * 
	 * @param name
	 *            操作人账号
	 * @param dbType
	 *            数据类型{@link SvnConfig}
	 * @param versionId
	 *            版本号
	 * @param files
	 *            操作的文件组
	 * @return true|false
	 * 
	 * @author wxl
	 * @date 2017年11月9日 下午2:13:14
	 */
	public boolean addLog(String name, SvnConfig dbType, long versionId, File[] files);

	/**
	 * 获取日志
	 * 
	 * @param name
	 *            操作人账号
	 * @param startTime
	 *            日志开始时间
	 * @param endTime
	 *            日志结束时间
	 * @return T 类型列表
	 * 
	 * @author wxl
	 * @date 2017年11月9日 下午2:13:14
	 */
	public List<? super T> getLog(String name, Date startTime, Date endTime);
}

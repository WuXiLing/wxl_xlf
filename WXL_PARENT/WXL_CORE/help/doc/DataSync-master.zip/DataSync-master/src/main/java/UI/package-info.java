/**
 * UI显示层，入口为AppMainWindow，ConstantsUI中包含了涉及主题和语言的常量， panel包为各子面板
 */
/**
 * @author zhouy
 *
 */
package UI;
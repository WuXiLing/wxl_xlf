package avicit.platform6.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.xml.bind.JAXBException;

import UI.ConstantsUI;
import avicit.platform6.code.utils.JaxbUtil;
import avicit.platform6.code.utils.bean.Avicit;

public class Test {

	public static void main(String[] args) {
		try {
//			Avicit avicit = new Avicit();
//			Task task = new Task();
//			task.setSvnPwd("ss");
//			task.setSvnUrl("sdsd");
//			task.setSvnUser("sdsd");
//			task.setTaskName("sdsd");
//			avicit.addTask(task);
//			try {
//				JaxbUtil.convertToXml(avicit, ConstantsUI.CURRENT_DIR + File.separator + "config" + File.separator + "tasks.xml");
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
			File file = new File(ConstantsUI.CURRENT_DIR + File.separator + "config" + File.separator + "tasks.xml");
			if(file.exists()){
				Avicit avicit = JaxbUtil.converyToJavaBean(file, Avicit.class);
			}
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static String readContents(String filePath) throws IOException {
		StringBuilder rString = new StringBuilder("");
		InputStreamReader inputStream = new InputStreamReader(new FileInputStream(filePath));
		if (inputStream != null) {
			BufferedReader bufferedReader = new BufferedReader(inputStream);
			String lineTxt = null;
			while ((lineTxt = bufferedReader.readLine()) != null) {
				rString.append(lineTxt);
			}
			bufferedReader.close();
		}
		return rString.toString();
	}
}

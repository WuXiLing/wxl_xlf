package avicit.platform6.svn.impl;

import avicit.platform6.svn.inf.ISvnService;

/**
 * {@link ISvnService} 池的实现
 * 
 * @author wxl
 *
 */
public class SvnServicePoolImpl extends SvnCommonImpl implements ISvnService {

	@Override
	public void createSVNRepository() {
		// TODO Auto-generated method stub

	}

	@Override
	public void closeRepo() {
		// TODO Auto-generated method stub

	}

	@Override
	public void createSVNClientManager() {
		// TODO Auto-generated method stub

	}

}

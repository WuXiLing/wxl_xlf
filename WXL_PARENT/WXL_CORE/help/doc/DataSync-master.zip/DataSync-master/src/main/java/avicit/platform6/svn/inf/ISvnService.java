package avicit.platform6.svn.inf;

import org.tmatesoft.svn.core.SVNException;

/**
 * svn主服务创建
 * 
 * @author wxl
 *
 */
public interface ISvnService {

	/**
     * 创建SNV版本库服务
	 * @throws SVNException 
     * 
     */
    public void createSVNRepository() throws SVNException;

    /**
     * 关闭版本库容器,便于刷新重连等
     * 
     */
    public void closeRepo();

    /**
     * 创建svn客户操作服务
     * 
     */
    public void createSVNClientManager();
}

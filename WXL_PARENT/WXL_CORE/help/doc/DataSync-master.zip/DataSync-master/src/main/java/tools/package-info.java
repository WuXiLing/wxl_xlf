/**
 * 本包为工具包，包含各工具类
 */
/**
 * @author zhouy
 *
 */
package tools;